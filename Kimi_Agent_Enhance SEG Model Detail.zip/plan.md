# SEG Visualization Enhancement Plan

## Stage 1: Analysis (Completed)
- Reviewed current codebase (main.js, multi-device-visualizer.js, device-instance.js)
- Downloaded and analyzed 15+ real SEG device photographs
- Key references: Roschin & Godin replica, Bharath prototype, Searl original

## Stage 2: Identify Gaps Between Current Viz and Real Device

### Current Model:
- Central hub: simple sphere (radius 1.2)
- Rollers: smooth cylinders, 3 rings (8+12+16 = 36 rollers)
- Plates: 4 flat annuli with zero surface detail
- Coils: single torus
- Materials: flat copper color, basic lighting

### Real Device Has:
1. **Central bearing shaft** - not a sphere; metallic shaft with flange
2. **Patterned rollers** - magnetic pole laminations visible as bands/stripes
3. **Plates with cutouts** - upper/lower plates have roller-sized holes/notches
4. **Support legs/stand** - structural base with mounting feet
5. **Wiring harness** - visible wires connecting electromagnets
6. **Multi-material composition** - neodymium (silver), copper (reddish), brass (gold), insulation
7. **Bolt details** - fasteners around plate perimeters
8. **Coil windings** - electromagnets with visible copper wire turns

## Stage 3: Produce Enhanced Geometry Module
- Output: `seg-enhanced-geometry.js` - drop-in enhancements for device-geometry.js
- New procedural geometry generators for detailed components
- Enhanced materials with metallic roughness variation
- Additional instance data for roller patterning

## Stage 4: Produce Enhanced Shader Snippets
- Output: `seg-enhanced-shaders.wgsl` - fragment shader enhancements
- Roller band pattern based on UV coordinates
- Improved metallic material response
- Wire/cable rendering

## Stage 5: Integration Guide
- Document how to integrate into existing codebase
