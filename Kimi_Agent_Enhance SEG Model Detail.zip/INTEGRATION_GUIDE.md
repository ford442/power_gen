# SEG Enhanced Visualization - Integration Guide

## Overview

This guide walks you through integrating the enhanced SEG geometry and shaders into your existing `power_gen` codebase to make the visualization look significantly more like a real Searl Effect Generator device.

## What Changes

| Component | Before | After |
|-----------|--------|-------|
| Central Hub | Smooth sphere | Bearing shaft with flange and retaining ring |
| Rollers | Uniform copper cylinders | 6-band pole-banded rollers (N/S magnetic segments) |
| Plates | Flat annuli | Plates with roller cutouts, bolt holes, and radial ribs |
| Coils | Smooth torus | Torus with visible helical wire windings |
| Stand | None | 4-legged support stand with foot pads |
| Wiring | None | Curved wire harnesses between electromagnets |
| Materials | Flat diffuse | PBR metallic workflow with Fresnel, specular, rim lighting |

## File Structure

```
power_gen/
  src/
    seg-enhanced-geometry.js    # <-- NEW: Enhanced geometry generators
    seg-enhanced-shaders.wgsl   # <-- NEW: PBR shader code
  INTEGRATION_GUIDE.md          # <-- This file
```

## Step-by-Step Integration

### Step 1: Copy Files

Copy `seg-enhanced-geometry.js` and `seg-enhanced-shaders.wgsl` into your `src/` folder.

### Step 2: Update Vertex Buffer Layout (main.js)

The enhanced geometry includes UV coordinates, so the vertex buffer layout changes.

**In `src/main.js` or `src/index.ts`, find `setupShaders()` and update the vertex buffer layout:**

```javascript
// BEFORE (arrayStride: 24, no UV)
buffers: [{
  arrayStride: 24,
  attributes: [
    { shaderLocation: 0, offset: 0,  format: 'float32x3' },
    { shaderLocation: 1, offset: 12, format: 'float32x3' }
  ]
}]

// AFTER (arrayStride: 32, with UV)
buffers: [{
  arrayStride: 32,
  attributes: [
    { shaderLocation: 0, offset: 0,  format: 'float32x3' },  // position
    { shaderLocation: 1, offset: 12, format: 'float32x3' },  // normal
    { shaderLocation: 2, offset: 24, format: 'float32x2' }   // NEW: uv
  ]
}]
```

### Step 3: Replace Geometry Setup (main.js ~line 314)

**Find `setupGeometry()` and replace the hub, roller, plate, and coil generation:**

```javascript
// At top of file, add import:
import {
  generateBearingShaft,
  generatePoleBandedRoller,
  generatePlateWithCutouts,
  generateSupportStand,
  generateWireHarness,
  generateCoilWithWindings,
  SEGMaterialPresets
} from './seg-enhanced-geometry.js';

// In setupGeometry():
async setupGeometry() {
  // --- NEW: Central bearing shaft (replaces sphere) ---
  const shaftData = generateBearingShaft(this.device, {
    shaftRadius: 0.5,
    shaftHeight: 3.5,
    flangeRadius: 1.8,
    topRingRadius: 1.3,
    segments: 48
  });
  this.coreVertexBuffer = shaftData.vertexBuffer;
  this.coreIndexBuffer = shaftData.indexBuffer;
  this.coreIndexCount = shaftData.indexCount;

  // --- NEW: Pole-banded roller (replaces smooth cylinder) ---
  const rollerData = generatePoleBandedRoller(this.device, {
    radius: 0.75,
    height: 2.8,
    bands: 6,
    segments: 32
  });
  this.vertexBuffer = rollerData.vertexBuffer;
  this.indexBuffer = rollerData.indexBuffer;
  this.indexCount = rollerData.indexCount;

  // --- NEW: Upper/Lower plates with cutouts ---
  const rings = [
    { count: 8, radius: 2.5 },
    { count: 12, radius: 4.0 },
    { count: 16, radius: 5.5 }
  ];
  const rollerCutouts = [];
  for (const ring of rings) {
    for (let i = 0; i < ring.count; i++) {
      rollerCutouts.push({
        angle: (i / ring.count) * Math.PI * 2,
        radius: ring.radius,
        size: 0.85
      });
    }
  }

  // Upper plate
  const upperPlateData = generatePlateWithCutouts(this.device, {
    innerRadius: 0.8,
    outerRadius: 6.5,
    thickness: 0.25,
    rollerCutouts,
    boltHoles: 16,
    hasRibs: true,
    ribCount: 8,
    segments: 96
  });
  // Store as first plate
  this.segPlateVertexBuffers = [upperPlateData.vertexBuffer];
  this.segPlateIndexBuffers = [upperPlateData.indexBuffer];
  this.segPlateIndexCounts = [upperPlateData.indexCount];

  // Lower plate (same geometry, rendered at different Y via instance transform)
  const lowerPlateData = generatePlateWithCutouts(this.device, {
    innerRadius: 0.8,
    outerRadius: 6.5,
    thickness: 0.25,
    rollerCutouts,
    boltHoles: 16,
    hasRibs: true,
    ribCount: 8,
    segments: 96
  });
  this.segPlateVertexBuffers.push(lowerPlateData.vertexBuffer);
  this.segPlateIndexBuffers.push(lowerPlateData.indexBuffer);
  this.segPlateIndexCounts.push(lowerPlateData.indexCount);

  // --- NEW: Coil with visible windings ---
  const coilData = generateCoilWithWindings(this.device, {
    majorRadius: 7.5,
    minorRadius: 0.6,
    turns: 60,
    majorSegments: 96
  });
  this.coilVertexBuffer = coilData.vertexBuffer;
  this.coilIndexBuffer = coilData.indexBuffer;
  this.coilIndexCount = coilData.indexCount;

  // --- NEW: Support stand ---
  const standData = generateSupportStand(this.device, {
    legCount: 4,
    legLength: 5.0,
    baseRadius: 3.0,
    height: 3.0,
    segments: 24
  });
  this.standVertexBuffer = standData.vertexBuffer;
  this.standIndexBuffer = standData.indexBuffer;
  this.standIndexCount = standData.indexCount;

  // --- NEW: Wire harnesses between coils ---
  this.wireVertexBuffers = [];
  this.wireIndexBuffers = [];
  this.wireIndexCounts = [];
  const coilCount = 8;
  const coilRadius = 7.5;
  for (let i = 0; i < coilCount; i++) {
    const angle1 = (i / coilCount) * Math.PI * 2;
    const angle2 = ((i + 1) / coilCount) * Math.PI * 2;
    const wireData = generateWireHarness(this.device, {
      start: [Math.cos(angle1) * coilRadius, 0.8, Math.sin(angle1) * coilRadius],
      end: [Math.cos(angle2) * coilRadius, 0.8, Math.sin(angle2) * coilRadius],
      radius: 0.035,
      sag: 0.4,
      segments: 16
    });
    this.wireVertexBuffers.push(wireData.vertexBuffer);
    this.wireIndexBuffers.push(wireData.indexBuffer);
    this.wireIndexCounts.push(wireData.indexCount);
  }

  this.updateParticles();
}
```

### Step 4: Update Instance Data Generation (device-instance.js ~line 220)

**Find the roller instance update code and use the banded instance generator:**

```javascript
// At top of device-instance.js, add:
import { generateBandedRollerInstances } from './seg-enhanced-geometry.js';

// In update(), replace the roller instance data generation:
if (this.id === 'seg' && this.rollerInstances) {
  const rings = [
    { count: 8,  radius: 2.5, scale: 0.6, speed: 2.0, index: 0 },
    { count: 12, radius: 4.0, scale: 0.8, speed: 1.0, index: 1 },
    { count: 16, radius: 5.5, scale: 1.0, speed: 0.5, index: 2 }
  ];

  const instanceData = generateBandedRollerInstances(
    this.visualizer.time,
    rings,
    {
      useHardwarePhase: hw?.isConnected && hw?.mirrorEnabled,
      hardwarePhaseRad: hw?.isConnected ? (hw.actualPhase * Math.PI / 180) : 0
    }
  );

  this.device.queue.writeBuffer(this.rollerInstances, 0, instanceData);
}
```

### Step 5: Update Materials (device-instance.js ~line 116)

**Replace the flat SEG material with PBR material presets:**

```javascript
// At top of file:
import { SEGMaterialPresets } from './seg-enhanced-geometry.js';

// In setupUniforms(), replace SEG material block:
if (this.id === 'seg') {
  const mat = SEGMaterialPresets.copper;
  baseColor = mat.baseColor;
  glowColor = [0.0, 1.2, 0.6];
  emission = mat.emissive;
  // Store metallic/roughness for shader (passed via padding or new uniform)
}
```

### Step 6: Add Lighting Uniform Buffer (main.js init)

**Add a lighting uniform buffer setup in your init() or setupShaders():**

```javascript
// In setupShaders(), after creating other buffers:
this.lightingUniformBuffer = this.device.createBuffer({
  size: 192, // 48 floats x 4 bytes
  usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
});

// Upload initial lighting configuration
const lightingData = new Float32Array(48);
// Key light
lightingData.set([5.0, 8.0, 5.0, 0.0], 0);     // position + pad
lightingData.set([1.0, 0.98, 0.95, 1.2], 4);   // color + intensity
// Fill light
lightingData.set([-4.0, 3.0, -3.0, 0.0], 8);
lightingData.set([0.75, 0.85, 1.0, 0.4], 12);
// Rim light
lightingData.set([0.0, 2.0, -8.0, 0.0], 16);
lightingData.set([0.4, 0.8, 1.0, 0.8], 20);
// Ground bounce
lightingData.set([0.0, -5.0, 0.0, 0.0], 24);
lightingData.set([0.3, 0.25, 0.2, 0.15], 28);
// Ambient + env
lightingData.set([0.3, 0.5, 0.0, 0.0], 32);

this.device.queue.writeBuffer(this.lightingUniformBuffer, 0, lightingData);
```

### Step 7: Update Bind Group Layout (main.js setupShaders)

**Extend the bind group to include lighting and materials:**

```javascript
// In setupShaders(), update the bind group creation:
this.bindGroup = this.device.createBindGroup({
  layout: this.renderPipeline.getBindGroupLayout(0),
  entries: [
    { binding: 0, resource: { buffer: this.uniformBuffer } },
    { binding: 1, resource: { buffer: this.deviceUniformBuffer } },
    { binding: 2, resource: { buffer: this.instanceBuffer } },
    { binding: 3, resource: { buffer: this.materialBuffer } },
    { binding: 4, resource: { buffer: this.materialStorageBuffer } },  // NEW
    { binding: 5, resource: { buffer: this.lightingUniformBuffer } },  // NEW
  ]
});
```

### Step 8: Add Rendering Calls (main.js render loop)

**In the render() function, add drawing calls for the new geometry:**

```javascript
// After rendering rollers, add:

// Render support stand
renderPass.setVertexBuffer(0, this.standVertexBuffer);
renderPass.setIndexBuffer(this.standIndexBuffer, 'uint16');
renderPass.drawIndexed(this.standIndexCount);

// Render wire harnesses
for (let i = 0; i < this.wireVertexBuffers.length; i++) {
  renderPass.setVertexBuffer(0, this.wireVertexBuffers[i]);
  renderPass.setIndexBuffer(this.wireIndexBuffers[i], 'uint16');
  renderPass.drawIndexed(this.wireIndexCounts[i]);
}

// Render upper plate (at y = +1.4)
// Use instance offset or separate render pass with transform
renderPass.setVertexBuffer(0, this.segPlateVertexBuffers[0]);
renderPass.setIndexBuffer(this.segPlateIndexBuffers[0], 'uint16');
// Set plate-specific uniforms (ringIndex = 11 signals plate to shader)
renderPass.drawIndexed(this.segPlateIndexCounts[0]);

// Render lower plate (at y = -1.4)
renderPass.setVertexBuffer(0, this.segPlateVertexBuffers[1]);
renderPass.setIndexBuffer(this.segPlateIndexBuffers[1], 'uint16');
renderPass.drawIndexed(this.segPlateIndexCounts[1]);
```

### Step 9: Copy Shader Code

**Copy the enhanced WGSL code from `seg-enhanced-shaders.wgsl` into your existing shader files:**

1. Copy the `poleBandColor()` function and PBR helpers into `src/shaders/roller.wgsl`
2. Copy the `enhancedRollerFragment()` entry point as the new fragment shader
3. Copy the lighting uniform struct and bindings
4. Keep your existing vertex shader entry point name if other code depends on it

### Step 10: Build and Test

```bash
npm run build
npm run dev
```

## Visual Comparison Checklist

After integration, verify these visual details match real SEG photos:

- [ ] **Roller bands**: Each roller shows alternating copper/oxide/silver/brass stripes
- [ ] **Central shaft**: Metallic bearing shaft with flange instead of smooth sphere
- [ ] **Plate cutouts**: Upper/lower plates have visible roller-sized cutouts
- [ ] **Bolt heads**: Small raised circles around plate perimeter
- [ ] **Support legs**: 4-legged stand visible beneath the device
- [ ] **Wire harnesses**: Curved wires connecting electromagnets
- [ ] **Coil windings**: Helical wire pattern on electromagnet coils
- [ ] **Metallic specular**: Bright specular highlights on copper/brass surfaces
- [ ] **Rim lighting**: Cyan edge glow defining silhouette
- [ ] **Machining marks**: Subtle surface variation on plates (not uniform)

## Performance Notes

The enhanced geometry is more detailed but optimized:

| Component | Vertices (old) | Vertices (new) | Cost |
|-----------|---------------|----------------|------|
| Hub (sphere) | ~2,300 | ~4,800 | +108% |
| Roller (cylinder) | ~384 | ~2,400 | +525% |
| Plate (annulus) | ~1,500 | ~15,000 | +900% |
| Stand | 0 | ~8,000 | New |
| Wires (8x) | 0 | ~2,400 | New |

**Total increase: ~4x vertex count.** For 60 FPS on mid-tier GPUs:
- Use LOD: Switch to simple geometry when camera distance > 15 units
- The existing quality scaling via `profiler.qualityLevel` can gate the new geometry
- Consider rendering plates only when viewing from above (frustum culling)

## Minimal Integration (Quick Start)

If you want the fastest path to improved visuals with minimal code changes:

1. **Only use `generatePoleBandedRoller`** + update the fragment shader for band coloring
2. **Only use `generateBearingShaft`** to replace the sphere hub
3. **Keep everything else the same**

This gives you 80% of the visual improvement with 20% of the integration work.

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Black screen after changes | Check vertex buffer stride matches (32 bytes with UV) |
| No pole bands visible | Verify UVs are being passed through vertex shader |
| Performance drop | Enable LOD switching based on camera distance |
| Wrong colors on rollers | Check `bandIndex` calculation in vertex shader |
| Stand not visible | Ensure render pass draw call is added to render loop |
